# Trixanth integration dry-run kit (ROS 2 Jazzy)

## Install as a NEW package
Copy directory `trixanth_demo` into `<trixanth_ws>/src/` (NOT inside a package). Do not overwrite existing Trixanth files.
`source /opt/ros/jazzy/setup.bash && cd ~/trixanth_ws && colcon build --packages-select trixanth_demo trixanth_comms trixanth_interfaces --symlink-install && source install/setup.bash`
`ros2 launch trixanth_demo bench.launch.py`
This launches phone UDP sensor input, existing command gate, and a NO-HARDWARE command sink.

## UDP protocol, port 5005 (one UTF-8 JSON object per datagram)
The phone needs a sender app/script configured to send matching packets to the Pi's IP address. This package does NOT itself install a phone app.
Example IMU: `{ "type":"imu", "angular_velocity":{"x":0,"y":0,"z":0.1}, "linear_acceleration":{"x":0,"y":0,"z":9.81} }`
Optional: `"orientation":{"x":0,"y":0,"z":0,"w":1}` **ONLY after converting a calibrated phone orientation into ROS ENU conventions**.
Example GPS: `{ "type":"gps", "lat":12.9, "lon":77.6, "alt":900, "horizontal_accuracy_m":15, "valid":true }`
DO NOT send raw Android phone-axis IMU data without rotating into ROS base/phone frames. Rigidly fix phone on rover and verify transformations.
GPS measured accuracy is not guaranteed; use app-supplied horizontal accuracy if available.

## Bench tests (Pi)
`ros2 topic echo /imu/data --once`
`ros2 topic echo /gps/fix --once`
`ros2 topic pub --once /cmd_vel_auto geometry_msgs/msg/Twist '{linear: {x: 0.0}, angular: {z: 0.0}}'`
The command gate defaults to IDLE; `/cmd_vel` remains zero until deliberately switching modes. DO NOT bypass it on physical hardware.

## Important architecture limits
- This kit does NOT publish fabricated wheel odometry or claim working GPS navigation. Existing dual EKF requires `/odom/wheel` and suitable orientation; GPS/IMU alone do not create local odometry.
- AMCL requires map + laser/2D observation; phone GPS is not a substitute.
- Existing Trixanth repository does NOT contain a FlySky receiver decoder; plan i-BUS/SBUS/PWM adapter after receiver model and electrical levels are confirmed.
- Existing camera launch assumes RealSense; update camera driver and point cloud topic after confirming model.
- Existing `robot.launch.py` should NOT run tonight; it starts drivers for unavailable hardware and references a missing URDF.
- Never wire motor output without independent motor-power E-stop and driver-specific electrical verification.
- A packet format is not a mobile app: choose a phone sensor app capable of mapping/forwarding the requested fields or adapt this node to its protocol.
